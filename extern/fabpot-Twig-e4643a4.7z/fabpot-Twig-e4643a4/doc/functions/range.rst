``range``
=========

Returns a list containing an arithmetic progression of integers:

.. code-block:: jinja

    {% for i in range(0, 3) %}
        {{ i }},
    {% endfor %}

    {# returns 0, 1, 2, 3 #}

When step is given (as the third parameter), it specifies the increment (or
decrement):

.. code-block:: jinja

    {% for i in range(0, 6, 2) %}
        {{ i }},
    {% endfor %}

    {# returns 0, 2, 4, 6 #}

The Twig built-in ``..`` operator is just syntactic sugar for the ``range``
function (with a step of 1):

.. code-block:: jinja

    {% for i in 0..3 %}
        {{ i }},
    {% endfor %}

.. tip::

    The ``range`` function works as the native PHP `range`_ function.

.. _`range`: http://php.net/range
